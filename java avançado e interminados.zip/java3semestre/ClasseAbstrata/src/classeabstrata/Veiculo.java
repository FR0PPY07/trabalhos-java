
package classeabstrata;

public abstract class Veiculo {
    
    public String placa, cor;
    public int ano;
    public Double preco;
    public Proprietario proprietario;

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getReco() {
        return preco;
    }

    public void setReco(Double reco) {
        this.preco = reco;
    }

    public Proprietario getProprietario() {
        return proprietario;
    }

    public void setProprietario(Proprietario proprietario) {
        this.proprietario = proprietario;
    }

    public Veiculo(String placa, String cor, int ano, Double preco, Proprietario proprietario) {
        this.placa = placa;
        this.cor = cor;
        this.ano = ano;
        this.preco = preco;
        this.proprietario = proprietario;
    }
    
    public abstract Double ipva();
    public abstract Double seguro();
    public abstract String toString();
}

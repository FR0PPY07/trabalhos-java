
package classeabstrata;

public class Moto extends Veiculo{
    
    public int cilindradas;
    public Montadora montadora;

    public int getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }

    public Montadora getMontadora() {
        return montadora;
    }

    public void setMontadora(Montadora montadora) {
        this.montadora = montadora;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getReco() {
        return preco;
    }

    public void setReco(Double reco) {
        this.preco = reco;
    }

    public Proprietario getProprietario() {
        return proprietario;
    }

    public void setProprietario(Proprietario proprietario) {
        this.proprietario = proprietario;
    }

    public Moto(int cilindradas, Montadora montadora, String placa, String cor, int ano, Double preco, Proprietario proprietario) {
        super(placa, cor, ano, preco, proprietario);
        this.cilindradas = cilindradas;
        this.montadora = montadora;
    }
    
    public Double ipva(){
        return (preco*0.08);
    }
    public Double seguro(){
        return (preco*0.05);
    }

    @Override
    public String toString() {
        return "Moto{" + "cilindradas=" + cilindradas + ", montadora=" + montadora + '}';
    }
    
    
}

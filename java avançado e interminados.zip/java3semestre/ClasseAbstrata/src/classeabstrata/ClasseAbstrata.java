
package classeabstrata;

public class ClasseAbstrata {

    public static void main(String[] args) {
        
        DePasseio p = new DePasseio("ford", "vermelho grande",
                        new Montadora("111222", "alice",
                            new Endereco("rua 3","00009999")),"ovo09j2", "azul", 2012, 12000.00,
                        new Proprietario("1112223", "eduardo", 
                            new Endereco("rua 1", "11113222")));
        
        Onibus o = new Onibus(20, 
                    new Montadora("22221111", "estevao",
                        new Endereco("rua 2", "00001111")), "fhw1234", "preto", 2020, 50000.00,
                    new Proprietario("33331111", "guiherme", 
                        new Endereco("rua 4", "09")));
        
        Moto m = new Moto(300, 
                    new Montadora("22228888", "mily", 
                        new Endereco("rua 7", "44")),"jdfh432", "rosa", 2025, 120000.00,
                    new Proprietario("88775544", "Danilo", 
                    new Endereco("rua 3", "08")));
        
        
        System.out.println(p);
        System.out.println(o);
        System.out.println(m);
    }
    
}

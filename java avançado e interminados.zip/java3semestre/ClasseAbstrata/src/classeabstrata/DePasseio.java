
package classeabstrata;

public class DePasseio extends Veiculo {
    
    public String marca, descricao;
    public Montadora montadora;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Montadora getMontadora() {
        return montadora;
    }

    public void setMontadora(Montadora montadora) {
        this.montadora = montadora;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getReco() {
        return preco;
    }

    public void setReco(Double reco) {
        this.preco = reco;
    }

    public Proprietario getProprietario() {
        return proprietario;
    }

    public void setProprietario(Proprietario proprietario) {
        this.proprietario = proprietario;
    }

    public DePasseio(String marca, String descricao, Montadora montadora, String placa, String cor, int ano, Double preco, Proprietario proprietario) {
        super(placa, cor, ano, preco, proprietario);
        this.marca = marca;
        this.descricao = descricao;
        this.montadora = montadora;
    }
    
    public Double ipva(){
        return (preco * 0.03);
    }
    public Double seguro(){
        return (preco * 0.015);
    }

    @Override
    public String toString() {
        return "DePasseio{" + "marca= " + marca + ", descricao= " + descricao + ", montadora= " + montadora + "ipva= " + ipva() + "seguro= " + seguro() +'}';
    }
    
    
}


package classeabstrata;

public class Onibus extends Veiculo{
    
    public int atdPassageiros;

    public Montadora montadora;

    public int getAtdPassageiros() {
        return atdPassageiros;
    }

    public void setAtdPassageiros(int atdPassageiros) {
        this.atdPassageiros = atdPassageiros;
    }

    public Montadora getMontadora() {
        return montadora;
    }

    public void setMontadora(Montadora montadora) {
        this.montadora = montadora;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getReco() {
        return preco;
    }

    public void setReco(Double reco) {
        this.preco = reco;
    }

    public Proprietario getProprietario() {
        return proprietario;
    }

    public void setProprietario(Proprietario proprietario) {
        this.proprietario = proprietario;
    }

    public Onibus(int atdPassageiros, Montadora montadora, String placa, String cor, int ano, Double preco, Proprietario proprietario) {
        super(placa, cor, ano, preco, proprietario);
        this.atdPassageiros = atdPassageiros;
        this.montadora = montadora;
    }

    public Double ipva(){
        return (preco*0.05);
    }
    public Double seguro(){
        return (preco * 0.025);
    }
    
    @Override
    public String toString() {
        return "Onibus{" + "atdPassageiros=" + atdPassageiros + ", montadora=" + montadora + '}';
    }
    
    
}

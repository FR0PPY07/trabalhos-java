
package classeabstrata;

public class Proprietario {
    
    public String cpf, nome;
    
    public Endereco endereco;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Proprietario(String cpf, String nome, Endereco endereco) {
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "Proprietario{" + "cpf=" + cpf + ", nome=" + nome + ", endereco=" + endereco + '}';
    }
    
    
}


package herançaassociacao;


public class Imovel {
    private String especificacao;
    private String endereco;
    private String bairro;

    public String getEspecificacao() {
        return especificacao;
    }

    public void setEspecificacao(String especificacao) {
        this.especificacao = especificacao;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public Imovel(String especificacao, String endereco, String bairro) {
        this.especificacao = especificacao;
        this.endereco = endereco;
        this.bairro = bairro;
    }

    @Override
    public String toString() {
        return "Imovel{" + "especificacao=" + especificacao + ", endereco=" + endereco + ", bairro=" + bairro + '}';
    }
    
    
    
}

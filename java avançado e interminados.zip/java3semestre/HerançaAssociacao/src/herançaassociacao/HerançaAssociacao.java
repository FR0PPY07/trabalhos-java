
package herançaassociacao;
public class HerançaAssociacao {
    public static void main(String[] args) {
        
        Proprietario p = new Proprietario (2000.00, 
                new Imovel ("nao sei", "qnh", "taguatinga"), "000111", "danilo");
        
        Inquilino i = new Inquilino ("casa", 5000.00,
                new ContratoDeAlugel ("nao sei", "amanha",
                        new Mensalidade ("janeiro", 1000.00),
                        new Imovel ("nao sei", "qnc", "taguatinga")),
                new Referencia ("alan","0001", "qnt"),
                new Profissao ("medico"),"999888", "marcio");
     
    }
    
    
}


package herançaassociacao;


public class Inquilino extends Pessoa{
    
    private String localDeTrabalho;
    private Double salario;
    private ContratoDeAlugel contratoDeAlugel;
    private Referencia referencia;
    private Profissao profissao;

    public String getLocalDeTrabalho() {
        return localDeTrabalho;
    }

    public void setLocalDeTrabalho(String localDeTrabalho) {
        this.localDeTrabalho = localDeTrabalho;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public ContratoDeAlugel getContratoDeAlugel() {
        return contratoDeAlugel;
    }

    public void setContratoDeAlugel(ContratoDeAlugel contratoDeAlugel) {
        this.contratoDeAlugel = contratoDeAlugel;
    }

    public Referencia getReferencia() {
        return referencia;
    }

    public void setReferencia(Referencia referencia) {
        this.referencia = referencia;
    }

    public Profissao getProfissao() {
        return profissao;
    }

    public void setProfissao(Profissao profissao) {
        this.profissao = profissao;
    }

    public Inquilino(String localDeTrabalho, Double salario, ContratoDeAlugel contratoDeAlugel, Referencia referencia, Profissao profissao, String cpf, String nome) {
        super(cpf, nome);
        this.localDeTrabalho = localDeTrabalho;
        this.salario = salario;
        this.contratoDeAlugel = contratoDeAlugel;
        this.referencia = referencia;
        this.profissao = profissao;
    }

    @Override
    public String toString() {
        return "Inquilino{" + "localDeTrabalho=" + localDeTrabalho + ", salario=" + salario + ", contratoDeAlugel=" + contratoDeAlugel + ", referencia=" + referencia + ", profissao=" + profissao + '}';
    }
    
    

    
   
    
    
}

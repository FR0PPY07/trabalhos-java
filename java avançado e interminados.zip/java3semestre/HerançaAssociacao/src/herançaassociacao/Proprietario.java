
package herançaassociacao;

public class Proprietario extends Pessoa{
    
    private Double renda;
    private Imovel imovel;

    public Double getRenda() {
        return renda;
    }

    public void setRenda(Double renda) {
        this.renda = renda;
    }

    public Imovel getImovel() {
        return imovel;
    }

    public void setImovel(Imovel imovel) {
        this.imovel = imovel;
    }

    public Proprietario(Double renda, Imovel imovel, String cpf, String nome) {
        super(cpf, nome);
        this.renda = renda;
        this.imovel = imovel;
    }

    @Override
    public String toString() {
        return "Proprietario{" + "renda=" + renda + ", imovel=" + imovel + '}';
    }
    

    
    
}

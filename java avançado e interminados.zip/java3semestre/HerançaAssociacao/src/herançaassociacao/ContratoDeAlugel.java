
package herançaassociacao;


public class ContratoDeAlugel {
    
    private String descricao;
    private String validade;
    private Mensalidade mensalidade;
    private Imovel imovel;

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getValidade() {
        return validade;
    }

    public void setValidade(String validade) {
        this.validade = validade;
    }

    public Mensalidade getMensalidade() {
        return mensalidade;
    }

    public void setMensalidade(Mensalidade mensalidade) {
        this.mensalidade = mensalidade;
    }

    public Imovel getImovel() {
        return imovel;
    }

    public void setImovel(Imovel imovel) {
        this.imovel = imovel;
    }

    public ContratoDeAlugel(String descricao, String validade, Mensalidade mensalidade, Imovel imovel) {
        this.descricao = descricao;
        this.validade = validade;
        this.mensalidade = mensalidade;
        this.imovel = imovel;
    }

    @Override
    public String toString() {
        return "ContratoDeAlugel{" + "descricao=" + descricao + ", validade=" + validade + ", mensalidade=" + mensalidade + ", imovel=" + imovel + '}';
    }
    
    

    

    
    
    
}

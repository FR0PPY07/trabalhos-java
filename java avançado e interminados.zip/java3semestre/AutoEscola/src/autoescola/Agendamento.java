
package autoescola;

public class Agendamento {
    
    private String data, horario;
    private int numero;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Agendamento(String data, String horario, int numero) {
        this.data = data;
        this.horario = horario;
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Agendamento{" + "data=" + data + ", horario=" + horario + ", numero=" + numero + '}';
    }
    
    
}


package autoescola;


public class AutoEscola {

    
    public static void main(String[] args) {
        
        CursoTeorico c = new CursoTeorico("carrinhos", "hoje", "amanha", 24.00,
                            new Aluno("111.222", "maria", "rau3"),
                            new DoCursoTeorico("volante", "000333", "jose"),
                            new Escrito(30, 8.00, 
                                new Agendamento("hoje", "agora", 1122), "eduardo",
                                new Aluno("222.111", "eduardo", "rua4")),
                            new Teorica("olacas", "amanha"));
        
        Pratico p = new Pratico("dia 5", "esquina", 80.00,
                        new Agendamento("dia 5", "17h", 1123), 
                        new FiscalDetran(12, "marta"),
                        new Veiculo("jk5p00", "sandero", 2015),  "prova pratica",
                        new Aluno("333.111", "fatima", "rua5"));
        
        DeSaude s = new DeSaude("gustavo", 1,
                        new Laudo("antes de ontem", "miopia"),"prova de saude",
                        new Aluno("111.333", "antonio", "rua6"));
        
        Pratica pa = new Pratica("agora", "aqui", 
                        new Aluno("333.222", "voce", "rua1"),
                        new DeAulaPratica("segunda", "333.000", "antonieta"),
                        new Simulador(5, 
                            new Agendamento("dia 9", "14h", 1124)),
                        new Veiculo("aaa000", "ford", 2020), "todo dia"); 
          
        
        System.out.println(c);
        System.out.println(p);
        System.out.println(s);
        System.out.println(pa);
    }
    
}


package autoescola;

public class Teorica extends Aula {
    
    private String conteudo;

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public Teorica(String conteudo, String data) {
        super(data);
        this.conteudo = conteudo;
    }

    @Override
    public String toString() {
        return "Teorica{" + "conteudo=" + conteudo + '}';
    }
    
    
}

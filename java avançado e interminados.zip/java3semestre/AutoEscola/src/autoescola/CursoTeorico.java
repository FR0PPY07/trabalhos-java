
package autoescola;

public class CursoTeorico {
    
   private String nome, dataIncio, dataTermino;
   private Double cargaHoraria;
   private Aluno aluno;
   private DoCursoTeorico doCursoTerorico;
   private Escrito escrito;
   private Teorica teorica;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataIncio() {
        return dataIncio;
    }

    public void setDataIncio(String dataIncio) {
        this.dataIncio = dataIncio;
    }

    public String getDataTermino() {
        return dataTermino;
    }

    public void setDataTermino(String dataTermino) {
        this.dataTermino = dataTermino;
    }

    public Double getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(Double cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public DoCursoTeorico getDoCursoTerorico() {
        return doCursoTerorico;
    }

    public void setDoCursoTerorico(DoCursoTeorico doCursoTerorico) {
        this.doCursoTerorico = doCursoTerorico;
    }

    public Escrito getEscrito() {
        return escrito;
    }

    public void setEscrito(Escrito escrito) {
        this.escrito = escrito;
    }

    public Teorica getTeorica() {
        return teorica;
    }

    public void setTeorica(Teorica teorica) {
        this.teorica = teorica;
    }

    public CursoTeorico(String nome, String dataIncio, String dataTermino, Double cargaHoraria, Aluno aluno, DoCursoTeorico doCursoTerorico, Escrito escrito, Teorica teorica) {
        this.nome = nome;
        this.dataIncio = dataIncio;
        this.dataTermino = dataTermino;
        this.cargaHoraria = cargaHoraria;
        this.aluno = aluno;
        this.doCursoTerorico = doCursoTerorico;
        this.escrito = escrito;
        this.teorica = teorica;
    }

    @Override
    public String toString() {
        return "CursoTeorico{" + "nome=" + nome + ", dataIncio=" + dataIncio + ", dataTermino=" + dataTermino + ", cargaHoraria=" + cargaHoraria + ", aluno=" + aluno + ", doCursoTerorico=" + doCursoTerorico + ", escrito=" + escrito + ", teorica=" + teorica + '}';
    }
   
   
}

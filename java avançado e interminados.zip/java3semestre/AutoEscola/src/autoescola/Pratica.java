
package autoescola;

public class Pratica extends Aula {
    
    private String hora, local;
    private Aluno aluno;
    private DeAulaPratica deAulaPratica; 
    private Simulador simulador;
    private Veiculo veiculo;

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public DeAulaPratica getDeAulaPratica() {
        return deAulaPratica;
    }

    public void setDeAulaPratica(DeAulaPratica deAulaPratica) {
        this.deAulaPratica = deAulaPratica;
    }

    public Simulador getSimulador() {
        return simulador;
    }

    public void setSimulador(Simulador simulador) {
        this.simulador = simulador;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public Pratica(String hora, String local, Aluno aluno, DeAulaPratica deAulaPratica, Simulador simulador, Veiculo veiculo, String data) {
        super(data);
        this.hora = hora;
        this.local = local;
        this.aluno = aluno;
        this.deAulaPratica = deAulaPratica;
        this.simulador = simulador;
        this.veiculo = veiculo;
    }

    @Override
    public String toString() {
        return "Pratica{" + "hora=" + hora + ", local=" + local + ", aluno=" + aluno + ", deAulaPratica=" + deAulaPratica + ", simulador=" + simulador + ", veiculo=" + veiculo + '}';
    }
    
    
    
}

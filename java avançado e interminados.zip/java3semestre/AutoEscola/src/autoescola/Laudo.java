
package autoescola;

public class Laudo {
    
    private String data, resultado;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public Laudo(String data, String resultado) {
        this.data = data;
        this.resultado = resultado;
    }

    @Override
    public String toString() {
        return "Laudo{" + "data=" + data + ", resultado=" + resultado + '}';
    }
    
    
}


package autoescola;

public class Aula {
    
    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Aula(String data) {
        this.data = data;
    }

    
    
}

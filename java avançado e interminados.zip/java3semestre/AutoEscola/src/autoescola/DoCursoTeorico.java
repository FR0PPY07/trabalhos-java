
package autoescola;

public class DoCursoTeorico extends Instrutor{
    
    
    private String nomeFormacao;

    public String getNomeFormacao() {
        return nomeFormacao;
    }

    public void setNomeFormacao(String nomeFormacao) {
        this.nomeFormacao = nomeFormacao;
    }

    public DoCursoTeorico(String nomeFormacao, String cpf, String nome) {
        super(cpf, nome);
        this.nomeFormacao = nomeFormacao;
    }

    @Override
    public String toString() {
        return "DoCursoTeorico{" + "nomeFormacao=" + nomeFormacao + '}';
    }
    
    
}

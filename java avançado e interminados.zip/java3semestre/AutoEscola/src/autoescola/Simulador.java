
package autoescola;
public class Simulador {
    
    private int qtdePontos;
    private Agendamento agendamento;

    public int getQtdePontos() {
        return qtdePontos;
    }

    public void setQtdePontos(int qtdePontos) {
        this.qtdePontos = qtdePontos;
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public Simulador(int qtdePontos, Agendamento agendamento) {
        this.qtdePontos = qtdePontos;
        this.agendamento = agendamento;
    }

    @Override
    public String toString() {
        return "Simulador{" + "qtdePontos=" + qtdePontos + ", agendamento=" + agendamento + '}';
    }
    
    
}

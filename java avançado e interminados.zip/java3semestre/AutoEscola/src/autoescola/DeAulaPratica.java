
package autoescola;

public class DeAulaPratica extends Instrutor {
    
    private String diaDeFolga;

    public String getDiaDeFolga() {
        return diaDeFolga;
    }

    public void setDiaDeFolga(String diaDeFolga) {
        this.diaDeFolga = diaDeFolga;
    }

    public DeAulaPratica(String diaDeFolga, String cpf, String nome) {
        super(cpf, nome);
        this.diaDeFolga = diaDeFolga;
    }

    @Override
    public String toString() {
        return "DeAulaPratica{" + "diaDeFolga=" + diaDeFolga + '}';
    }
    
    
}

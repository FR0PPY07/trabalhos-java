
package autoescola;

public class Pratico extends Exames {
    
    private String data, local;
    private Double nota;
    private Agendamento agendamento;
    private FiscalDetran fiscalDetran;
    private Veiculo veiculo;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        this.nota = nota;
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public FiscalDetran getFiscalDetran() {
        return fiscalDetran;
    }

    public void setFiscalDetran(FiscalDetran fiscalDetran) {
        this.fiscalDetran = fiscalDetran;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public Pratico(String data, String local, Double nota, Agendamento agendamento, FiscalDetran fiscalDetran, Veiculo veiculo, String nome, Aluno aluno) {
        super(nome, aluno);
        this.data = data;
        this.local = local;
        this.nota = nota;
        this.agendamento = agendamento;
        this.fiscalDetran = fiscalDetran;
        this.veiculo = veiculo;
    }

    @Override
    public String toString() {
        return "Pratico{" + "data=" + data + ", local=" + local + ", nota=" + nota + ", agendamento=" + agendamento + ", fiscalDetran=" + fiscalDetran + ", veiculo=" + veiculo + '}';
    }
    
    
}

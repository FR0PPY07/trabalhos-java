
package autoescola;

public class Escrito extends Exames {
    
    private int qtdeQuestoes;
    private Double nota;
    private Agendamento agendamento;

    public int getQtdeQuestoes() {
        return qtdeQuestoes;
    }

    public void setQtdeQuestoes(int qtdeQuestoes) {
        this.qtdeQuestoes = qtdeQuestoes;
    }

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        this.nota = nota;
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public Escrito(int qtdeQuestoes, Double nota, Agendamento agendamento, String nome, Aluno aluno) {
        super(nome, aluno);
        this.qtdeQuestoes = qtdeQuestoes;
        this.nota = nota;
        this.agendamento = agendamento;
    }

    @Override
    public String toString() {
        return "Escrito{" + "qtdeQuestoes=" + qtdeQuestoes + ", nota=" + nota + ", agendamento=" + agendamento + '}';
    }
    
    
}


package autoescola;

public class DeSaude extends Exames {
    
    private String nomeMedico;
    private int qtdeExames;
    private Laudo laudo;

    public String getNomeMedico() {
        return nomeMedico;
    }

    public void setNomeMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }

    public int getQtdeExames() {
        return qtdeExames;
    }

    public void setQtdeExames(int qtdeExames) {
        this.qtdeExames = qtdeExames;
    }

    public Laudo getLaudo() {
        return laudo;
    }

    public void setLaudo(Laudo laudo) {
        this.laudo = laudo;
    }

    public DeSaude(String nomeMedico, int qtdeExames, Laudo laudo, String nome, Aluno aluno) {
        super(nome, aluno);
        this.nomeMedico = nomeMedico;
        this.qtdeExames = qtdeExames;
        this.laudo = laudo;
    }

    @Override
    public String toString() {
        return "DeSaude{" + "nomeMedico=" + nomeMedico + ", qtdeExames=" + qtdeExames + ", laudo=" + laudo + '}';
    }
    
    
}

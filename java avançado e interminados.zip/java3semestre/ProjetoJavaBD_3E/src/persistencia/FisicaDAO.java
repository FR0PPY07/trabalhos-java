
package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Fisica;

public class FisicaDAO {
    
    protected static Connection connection;

protected static PreparedStatement st;

protected static ResultSet rs;

public static List<Fisica> leTodos() throws Exception{

List<Fisica> listFisica = new ArrayList<Fisica>();

try {

String sql = "SELECT * FROM Fisica";

connection = GerenteDeConexao.getConnection();

st = connection.prepareStatement(sql);

rs = st.executeQuery();

while (rs.next()) {

Fisica fisica = new Fisica();

fisica.setCpf(rs.getString("cpf"));

fisica.setNome(rs.getString("nome"));

fisica.setIdade(rs.getInt("idade"));

fisica.setAtendente(AtendenteDAO.leUm(rs.getInt("atendente_matr")));

listFisica.add(fisica);

}

st.close();

} catch (Exception e) {

System.out.println(e.getMessage());

}

return listFisica;

}

 

public static Fisica leUm(String cpf) throws Exception {

Fisica fisica = new Fisica();

try {

String sql = "SELECT * FROM Fisica WHERE cpf = ?";

connection = GerenteDeConexao.getConnection();

st = connection.prepareStatement(sql);

st.setString(1, cpf);

rs = st.executeQuery();

if (rs.next()) {

fisica.setCpf(rs.getString("cpf"));

fisica.setNome(rs.getString("nome"));

fisica.setIdade(rs.getInt("idade"));

fisica.setAtendente(AtendenteDAO.leUm(rs.getInt("atendente_matr")));

}

st.close();

} catch (SQLException e) {

System.out.println(e.getMessage());

}

return fisica;

}



public static int grava(String cpf,String nome,int idade,int matrAtendente) throws Exception {

int ret = 0;

try {

String sql = "INSERT INTO Fisica (cpf,nome,idade,atendente_matr) VALUES (?, ?, ?, ?)";

connection = GerenteDeConexao.getConnection();

st = connection.prepareStatement(sql);

st.setString(1, cpf);

st.setString(2, nome);

st.setInt(3, idade);

st.setInt(4, matrAtendente);

ret = st.executeUpdate();

st.close();

} catch (SQLException e) {

System.out.println(e.getMessage());

}

return ret;

}



public static int altera(String novoNome,int novaIdade,int novoAtendenteMatr,String cpf) throws Exception {

int ret = 0;

try {

String sql = "UPDATE Fisica SET nome = ?, idade = ?, atendente_matr = ? WHERE cpf = ?";

connection = GerenteDeConexao.getConnection();

st = connection.prepareStatement(sql);

st.setString(1, novoNome);

st.setInt(2, novaIdade);

st.setInt(3, novoAtendenteMatr);

st.setString(4, cpf);

ret = st.executeUpdate();

st.close();

} catch (SQLException e) {

System.out.println(e.getMessage());

}

return ret;

}



public static int exclui(String cpf) throws Exception {

int ret = 0;

try {

String sql = "DELETE FROM Fisica WHERE cpf = ?";

connection = GerenteDeConexao.getConnection();

st = connection.prepareStatement(sql);

st.setString(1, cpf);

ret = st.executeUpdate();

st.close();

} catch (SQLException e) {

System.out.println(e.getMessage());

}

return ret;

}
}

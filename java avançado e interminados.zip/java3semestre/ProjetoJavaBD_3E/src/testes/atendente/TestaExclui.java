
package testes.atendente;

import persistencia.AtendenteDAO;

public class TestaExclui {

    public static void main(String[] args)throws Exception {
     
        System.out.println(AtendenteDAO.exclui(10));
    }
    
}

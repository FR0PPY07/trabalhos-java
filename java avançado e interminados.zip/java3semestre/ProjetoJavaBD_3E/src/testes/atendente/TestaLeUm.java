
package testes.atendente;

import persistencia.AtendenteDAO;

public class TestaLeUm {

    public static void main(String[] args)throws Exception {
       
        System.out.println(AtendenteDAO.leUm(1));
    }
    
}

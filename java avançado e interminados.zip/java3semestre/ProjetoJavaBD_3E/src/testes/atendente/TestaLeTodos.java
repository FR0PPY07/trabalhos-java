
package testes.atendente;

import persistencia.AtendenteDAO;

public class TestaLeTodos {

    public static void main(String[] args)throws Exception {
     
      
        System.out.println(AtendenteDAO.leTodos());
    }
    
}

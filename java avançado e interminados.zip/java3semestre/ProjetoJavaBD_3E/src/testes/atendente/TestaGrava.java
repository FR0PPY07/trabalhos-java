
package testes.atendente;

import persistencia.AtendenteDAO;

public class TestaGrava {

    public static void main(String[] args)throws Exception {
       
        System.out.println(AtendenteDAO.grava(10, "Joaquim"));
    }
    
}

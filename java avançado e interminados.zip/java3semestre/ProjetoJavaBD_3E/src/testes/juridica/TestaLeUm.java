package testes.juridica;

import persistencia.JuridicaDAO;

public class TestaLeUm {
    public static void main(String[] args)throws Exception {
    
        System.out.println(JuridicaDAO.leUm("202020"));
    }
    
}

package testes.juridica;

import persistencia.JuridicaDAO;

public class TestaGrava {
    public static void main(String[] args)throws Exception {
    
        System.out.println(JuridicaDAO.grava("909090", "Atacadão ÉdeGraça", 5, 2));
    }
    
}

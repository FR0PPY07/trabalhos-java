package testes.juridica;

import persistencia.JuridicaDAO;

public class TestaAltera {
    public static void main(String[] args)throws Exception {
     
        System.out.println(JuridicaDAO.altera("Atacadão NãoÉdeGraça", 10, 1, "909090"));
    }
    
}

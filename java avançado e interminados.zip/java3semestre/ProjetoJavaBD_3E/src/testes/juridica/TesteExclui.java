/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes.juridica;

import persistencia.JuridicaDAO;

/**
 *
 * @author 385298
 */
public class TesteExclui {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        System.out.println(JuridicaDAO.exclui("909090"));
    }
    
}

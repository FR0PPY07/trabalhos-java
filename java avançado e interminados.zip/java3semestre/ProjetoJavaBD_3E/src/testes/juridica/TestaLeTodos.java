package testes.juridica;

import persistencia.JuridicaDAO;

public class TestaLeTodos {
    public static void main(String[] args)throws Exception {
       
        System.out.println(JuridicaDAO.leTodos());
    }
    
}


package main;


public class Funcionario {
    
    private String nome;
    private String cargo;
    private Double salario;
    private Treino treino;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public Treino getTreino() {
        return treino;
    }

    public void setTreino(Treino treino) {
        this.treino = treino;
    }

    public Funcionario(String nome, String cargo, Double salario, Treino treino) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
        this.treino = treino;
    }

    @Override
    public String toString() {
        return "\nFuncionario{" + "nome:" + nome + ", cargo:" + cargo + ", salario:" + salario + treino + '}';
    }
    
    
    
}

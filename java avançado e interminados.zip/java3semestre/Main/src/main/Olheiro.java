
package main;

public class Olheiro {
    
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Olheiro(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "\nOlheiro{" + "nome:" + nome + '}';
    }
    
    
    
}

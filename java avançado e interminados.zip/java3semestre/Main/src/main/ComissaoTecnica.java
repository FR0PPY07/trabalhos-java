
package main;


public class ComissaoTecnica {
    
    private String nome;
    private String qtdeMembros;
    private Calendario calendario;
    private Olheiro olheiro;
    private Elenco elenco;
    private Treino treino;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQtdeMembros() {
        return qtdeMembros;
    }

    public void setQtdeMembros(String qtdeMembros) {
        this.qtdeMembros = qtdeMembros;
    }

    public Calendario getCalendario() {
        return calendario;
    }

    public void setCalendario(Calendario calendario) {
        this.calendario = calendario;
    }

    public Olheiro getOlheiro() {
        return olheiro;
    }

    public void setOlheiro(Olheiro olheiro) {
        this.olheiro = olheiro;
    }

    public Elenco getElenco() {
        return elenco;
    }

    public void setElenco(Elenco elenco) {
        this.elenco = elenco;
    }

    public Treino getTreino() {
        return treino;
    }

    public void setTreino(Treino treino) {
        this.treino = treino;
    }

    public ComissaoTecnica(String nome, String qtdeMembros, Calendario calendario, Olheiro olheiro, Elenco elenco, Treino treino) {
        this.nome = nome;
        this.qtdeMembros = qtdeMembros;
        this.calendario = calendario;
        this.olheiro = olheiro;
        this.elenco = elenco;
        this.treino = treino;
    }

    @Override
    public String toString() {
        return "\nComissaoTecnica{" + "nome:" + nome + ", qtdeMembros:" + qtdeMembros + calendario + olheiro + elenco + treino + '}';
    }
    
    
    
}

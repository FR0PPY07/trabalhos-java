
package main;

public class Diretoria {
    
    private String nome;
    private Receita receita;
    private ComissaoTecnica comissaoTecnica;
    private Funcionario funcionario;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Receita getReceita() {
        return receita;
    }

    public void setReceita(Receita receita) {
        this.receita = receita;
    }

    public ComissaoTecnica getComissaoTecnica() {
        return comissaoTecnica;
    }

    public void setComissaoTecnica(ComissaoTecnica comissaoTecnica) {
        this.comissaoTecnica = comissaoTecnica;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Diretoria(String nome, Receita receita, ComissaoTecnica comissaoTecnica, Funcionario funcionario) {
        this.nome = nome;
        this.receita = receita;
        this.comissaoTecnica = comissaoTecnica;
        this.funcionario = funcionario;
    }

    @Override
    public String toString() {
        return "\nDiretoria{" + "nome:" + nome + receita + comissaoTecnica + funcionario + '}';
    }
    
    
    
}

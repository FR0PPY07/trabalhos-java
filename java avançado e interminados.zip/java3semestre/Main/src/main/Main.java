
package main;


public class Main {

    public static void main(String[] args) {
       
        Diretoria diretoria = new Diretoria ("sla", 
            new Receita (300.00, 50.00),
            
            new ComissaoTecnica ("sla2", "12", 
                new Calendario ("eu", "maracana"),
                new Olheiro ("sla3"),
                new Elenco ("joão", "goleiro", 10000.00, 
                    new Treino ("defesa"),
                    new Competicao ("sal", 1)),
                new Treino ("embaixadinha")),
            new Funcionario ("junior", "atacante", 20000.00,
                new Treino ("chute")));
        
        System.out.println(diretoria.toString());
        
    }
    
}

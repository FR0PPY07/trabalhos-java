
public class Professor extends Pessoa implements Imprimivel,EstadoOrigem{
    
    private String titulo;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Professor(String nome, Double salario,String titulo) {
        super(nome,salario);
        this.titulo = titulo;
    }
    
    public Double calculaSalario(){
        return salario + gratificacao;
    }
    
    public String toString(){
        return "\n Dados do professor" +
                "\n nome:" + getNome() +
                "\n titulo:" + getTitulo() +
                "\n salario:" + getSalario() +
                "\n salario final:" + calculaSalario() +
                "\n cidade:" + cidade +
                "\n Estado:" + Estado;                 
    }
}



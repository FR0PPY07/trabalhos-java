

public class ExemploInterface {

    public static void main(String[] args) {
        
        Professor p = new Professor("maria", 15000.00,"mestra");
        System.out.println(p);
    }
    
}

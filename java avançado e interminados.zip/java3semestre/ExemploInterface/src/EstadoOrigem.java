
public interface EstadoOrigem {
 
    String cidade = "brasilia";
    String Estado = "DF";
    int gratificacao = 900;
    
}

package main;

public class Main {

    
    public static void main(String[] args) {
        
        pesado p = new pesado(1, 2000, "logan", 5);
       
        gol g = new gol (2, 2007, 4, "wolksvagen", 1.5, 5);
        
        System.out.println(p.toString());
        System.out.println(g.toString());
    }
    
}

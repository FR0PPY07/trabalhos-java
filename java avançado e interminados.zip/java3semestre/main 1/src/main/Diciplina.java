
package main;


public class Diciplina {
    
    private String nome;
    private String cargaHoraria;
    private Professor professor;
    private Aluno aluno;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(String cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Diciplina(String nome, String cargaHoraria, Professor professor, Aluno aluno) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.professor = professor;
        this.aluno = aluno;
    }

    @Override
    public String toString() {
        return "Diciplina{" + "nome=" + nome + ", cargaHoraria=" + cargaHoraria + ", professor=" + professor + ", aluno=" + aluno + '}';
    }
    
    
    
    
    
}

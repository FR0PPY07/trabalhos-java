
package main;


public class Origem {
    
    private String pai;
    private String mae;
    private Cidade cidade;

    public String getPai() {
        return pai;
    }

    public void setPai(String pai) {
        this.pai = pai;
    }

    public String getMae() {
        return mae;
    }

    public void setMae(String mae) {
        this.mae = mae;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Origem(String pai, String mae, Cidade cidade) {
        this.pai = pai;
        this.mae = mae;
        this.cidade = cidade;
    }

    @Override
    public String toString() {
        return "Origem" + "pai=" + pai + ", mae=" + mae + ", cidade=" + cidade;
    }
    
   

    
    
    
}

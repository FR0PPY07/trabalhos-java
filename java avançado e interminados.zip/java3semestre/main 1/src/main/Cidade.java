
package main;


public class Cidade  {
    
    private String nome;
    private Estado estado;
    
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    

    public Cidade(String nome) {
        this.nome = nome;
    }

    public Cidade(String nome, Estado estado) {
        this.nome = nome;
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Cidade " + "nome = " + nome + ", Estado = " + estado;
    }
    
    

   
    
    
    
    
    
}

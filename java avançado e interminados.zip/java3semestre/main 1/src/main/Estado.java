package main;


public class Estado {
    
    private String nome;
    private String UF;
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public Estado(String nome, String UF) {
        this.nome = nome;
        this.UF = UF;
    }

    @Override
    public String toString() {
        return "Estado " + "nome = " + nome + ", UF = " + UF;
    }
    
    
    
}

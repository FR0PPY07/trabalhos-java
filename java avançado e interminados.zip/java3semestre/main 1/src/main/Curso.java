
package main;


public class Curso {
    
    private String nome;
    private int qtdSemestral;
    private int cargaHoraria;
    private Diciplina diciplina;
    private Aluno aluno;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQtdSemestral() {
        return qtdSemestral;
    }

    public void setQtdSemestral(int qtdSemestral) {
        this.qtdSemestral = qtdSemestral;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public Diciplina getDiciplina() {
        return diciplina;
    }

    public void setDiciplina(Diciplina diciplina) {
        this.diciplina = diciplina;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Curso(String nome, int qtdSemestral, int cargaHoraria, Diciplina diciplina, Aluno aluno) {
        this.nome = nome;
        this.qtdSemestral = qtdSemestral;
        this.cargaHoraria = cargaHoraria;
        this.diciplina = diciplina;
        this.aluno = aluno;
    }

    @Override
    public String toString() {
        return "Curso{" + "nome=" + nome + ", qtdSemestral=" + qtdSemestral + ", cargaHoraria=" + cargaHoraria + ", diciplina=" + diciplina + ", aluno=" + aluno + '}';
    }
    

    
    
    
    
}

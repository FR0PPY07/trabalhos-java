
package main;


public class Main {

    
    public static void main(String[] args) {
      
        Curso curso = new Curso ("ETB", 2, 1,
                new Diciplina ("matematica", "4 na semana",
                    new Professor ("10", "jose", "qnf 27",
                        new Aluno ("2", "nathalia", 
                            new Origem ("peapsi", "ferreira", 
                                new Cidade ("brasilia",
                                    new Estado ("distrito federal", "DF")))),
                        new Origem ("eduardo", "jose",
                            new Cidade ("brasilia",
                                    new Estado ("distrito federal", "DF")))),
                        new Aluno ("3", "pedro",
                            new Origem ("francisco", "juliana",
                                new Cidade ("brasilia",
                                    new Estado ("distrito federal", "DF"))))),
        
                new Aluno ("1", "mily",
                    new Origem ("israel", "sumira",
                        new Cidade ("brasilia",
                             new Estado ("distrito federal", "DF")))));
        
        System.out.println(curso);
        
                }

   
    
}

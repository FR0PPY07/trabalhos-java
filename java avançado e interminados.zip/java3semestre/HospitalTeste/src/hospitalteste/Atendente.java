
package hospitalteste;

public class Atendente extends Pessoa {
    
    private int matr;
    private Double salario;
    private Consultorio consultorio;

    public int getMatr() {
        return matr;
    }

    public void setMatr(int matr) {
        this.matr = matr;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(Consultorio consultorio) {
        this.consultorio = consultorio;
    }

    public Atendente(int matr, Double salario, Consultorio consultorio, String cpf, String nome) {
        super(cpf, nome);
        this.matr = matr;
        this.salario = salario;
        this.consultorio = consultorio;
    }
    
    public String toString() {
        return "\n atendente:" +
                "\n matricula:" + matr +
                "\n salario:" + salario +
                "\n consultorio:" + consultorio;
    }
}

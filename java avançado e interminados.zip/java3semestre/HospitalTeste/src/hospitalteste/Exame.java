
package hospitalteste;

public class Exame extends Procedimento {
    
    
    private String data;
    private Medicamento medicamento;
    private Consultorio consultorio;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(Medicamento medicamento) {
        this.medicamento = medicamento;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(Consultorio consultorio) {
        this.consultorio = consultorio;
    }

    public Exame(String data, Medicamento medicamento, Consultorio consultorio, int numero, String descricao, Double valor) {
        super(numero, descricao, valor);
        this.data = data;
        this.medicamento = medicamento;
        this.consultorio = consultorio;
    }
    
    public String toString() {
    return "\n exame:" +
            "\n data:" + data +
            "\n medicamento:" + medicamento +
            "\n Consultorio:" + consultorio;
            
    }
}


package hospitalteste;

public class Medicamento {
    
    
    private String nome;
    private Double dosagem;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getDosagem() {
        return dosagem;
    }

    public void setDosagem(Double dosagem) {
        this.dosagem = dosagem;
    }

    public Medicamento(String nome, Double dosagem) {
        this.nome = nome;
        this.dosagem = dosagem;
    }
    
    public String toString() {
        return "\n Medicamento" +
                "\n Nome:" + nome +
                "\n dosagem" + dosagem;
                        
    }
}

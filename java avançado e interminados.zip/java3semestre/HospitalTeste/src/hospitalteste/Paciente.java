
package hospitalteste;

public class Paciente extends Pessoa {
    
    private String endereco, telefone;
    private Prontuario prontuario;
    private PlanoDeSaude planoDeSaude;
    private Consultorio consultorio;

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Prontuario getProntuario() {
        return prontuario;
    }

    public PlanoDeSaude getPlanoDeSaude() {
        return planoDeSaude;
    }

    public void setPlanoDeSaude(PlanoDeSaude planoDeSaude) {
        this.planoDeSaude = planoDeSaude;
    }
    

    public void setProntuario(Prontuario prontuario) {
        this.prontuario = prontuario;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(Consultorio consultorio) {
        this.consultorio = consultorio;
    }

    public Paciente(String endereco, String telefone, Prontuario prontuario, PlanoDeSaude planoDeSaude, Consultorio consultorio, String cpf, String nome) {
        super(cpf, nome);
        this.endereco = endereco;
        this.telefone = telefone;
        this.prontuario = prontuario;
        this.planoDeSaude = planoDeSaude;
        this.consultorio = consultorio;
    }

    
    
    public String toString() {
        return "\n paciente:" +
                "\n endereco:" + endereco +
                "\n telefone:" + telefone +
                "\n prontuario:" + prontuario +
                "\n consultorio:" + consultorio;
    }
}

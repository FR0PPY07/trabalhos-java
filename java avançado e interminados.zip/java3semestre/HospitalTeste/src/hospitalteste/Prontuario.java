
package hospitalteste;

public class Prontuario {
    
    private int numero;
    private Medico medico;

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Prontuario(int numero, Medico medico) {
        this.numero = numero;
        this.medico = medico;
    }
    
    public String toString() {
        return "\n prontuario:" +
                "\n numero:" + numero +
                "\n medico:" + medico;
    }
}


package hospitalteste;

public class Consulta extends Procedimento {
    
    
    private String data, hora;
    private Consultorio consultorio;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(Consultorio consultorio) {
        this.consultorio = consultorio;
    }

    public Consulta(String data, String hora, Consultorio consultorio, int numero, String descricao, Double valor) {
        super(numero, descricao, valor);
        this.data = data;
        this.hora = hora;
        this.consultorio = consultorio;
    }
    
    public String toString() {
        return "\n consulta:" +
                "\n data:" + data +
                "\n hora:" + hora +
                "\n consultorio:" + consultorio;
    }
}

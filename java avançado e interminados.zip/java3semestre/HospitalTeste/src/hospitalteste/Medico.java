
package hospitalteste;

public class Medico extends Pessoa {
    
    
    private String crm, especialidade;
    private Consultorio consultorio;

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(Consultorio consultorio) {
        this.consultorio = consultorio;
    }

    public Medico(String crm, String especialidade, Consultorio consultorio, String cpf, String nome) {
        super(cpf, nome);
        this.crm = crm;
        this.especialidade = especialidade;
        this.consultorio = consultorio;
    }
    
    
    public String toString() {
        return "\n medico:" +
                "\n CRM:" + crm +
                "\n especialidade:" + especialidade +
                "\n consultorio:" + consultorio;
    }
}


package hospitalteste;

public class PlanoDeSaude {
    
    private String cnpj, nome, contrato;
    private Consultorio consultorio;

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(Consultorio consultorio) {
        this.consultorio = consultorio;
    }

    public PlanoDeSaude(String cnpj, String nome, String contrato, Consultorio consultorio) {
        this.cnpj = cnpj;
        this.nome = nome;
        this.contrato = contrato;
        this.consultorio = consultorio;
    }
    
    public String toString() {
        return "\n Plano de saude" +
                "\n CNPJ:" + cnpj +
                "\n Nome:" + nome +
                "\n  Contrato" + contrato +
                "\n Consultorio:" + consultorio;
    }
}

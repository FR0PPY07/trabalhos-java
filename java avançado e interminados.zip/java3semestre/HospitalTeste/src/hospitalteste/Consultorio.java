
package hospitalteste;

public class Consultorio {
   
    
    private int numero;
    private String localizacao;

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public Consultorio(int numero, String localizacao) {
        this.numero = numero;
        this.localizacao = localizacao;
    }

    
    public String toString() {
        return "\n consultorio:" +
                "\n Numero:" + numero +
                "\n Localização:" + localizacao;
    }
    
    
}

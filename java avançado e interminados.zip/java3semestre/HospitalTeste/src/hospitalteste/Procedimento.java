
package hospitalteste;

public class Procedimento {
    
    
    private int numero;
    private String descricao;
    private Double valor;

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Procedimento(int numero, String descricao, Double valor) {
        this.numero = numero;
        this.descricao = descricao;
        this.valor = valor;
    }
    
    
}


package hospitalteste;

public class HospitalTeste {

    public static void main(String[] args) {
        
        Exame e = new Exame("11/10/2025", 
                new Medicamento("dipirona", 15.00), 
                new Consultorio(1, "a3"), 5, "tosse", 100.00);
        
        Consulta c = new Consulta("12/10/2025", "17h", 
                new Consultorio(3, "b1"), 4, "diarreia", 100.00);
        
        Medicacao m = new Medicacao("dor", 5.00, 
                new Atendente(0001, 5000.00, 
                        new Consultorio(1, "a2"), "000111", "eduardo"),
                new Medicamento("paracetamol", 7.00), 3, "dor", 200.00);
        
        Medico mp = new Medico("321", "urologista", 
                new Consultorio(1, "a1"), "000222", "jessica");
        
        Paciente p = new Paciente("qne 6", "98765432", 
                new Prontuario(5,
                    new Medico("123", "pediatra",
                        new Consultorio(5, "b2"), "111222", "vitoria")), 
                new PlanoDeSaude("345667", "viva mais", "email", 
                    new Consultorio(2, "a3")), "543123", "joao");
        
    }
    
}


package hospitalteste;

public class Medicacao extends Procedimento {
    
    private String finalidade;
    private Double dosagem;
    private Atendente atendente;
    private Medicamento medicamento;

    public String getFinalidade() {
        return finalidade;
    }

    public void setFinalidade(String finalidade) {
        this.finalidade = finalidade;
    }

    public Double getDosagem() {
        return dosagem;
    }

    public void setDosagem(Double dosagem) {
        this.dosagem = dosagem;
    }

    public Atendente getAtendente() {
        return atendente;
    }

    public void setAtendente(Atendente atendente) {
        this.atendente = atendente;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public void setMeidcamento(Medicamento medicamento) {
        this.medicamento = medicamento;
    }

    public Medicacao(String finalidade, Double dosagem, Atendente atendente, Medicamento medicamento, int numero, String descricao, Double valor) {
        super(numero, descricao, valor);
        this.finalidade = finalidade;
        this.dosagem = dosagem;
        this.atendente = atendente;
        this.medicamento = medicamento;
    }
    
    public String toString() {
        return "\n medicação:" +
                "\n finalidade:" + finalidade +
                "\n dosagem:" + dosagem +
                "\n atendente:" + atendente +
                "\n medicamento:" + medicamento;
    }
}

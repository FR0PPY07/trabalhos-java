
package farmacia;
public class Farmacia {

    
    public static void main(String[] args) {
        
        Compra c = new Compra (1, "ontem", 50.00, 
                    new Pagamento ("cartao"),
                    new cliente ("000111", "maria", "2000", 
                        new Receita ("antes de ontem", 10.00,
                            new Farmaceutico ("farmacia", 1, "naty", 6000.00),
                            new Medicamento ("generico", "febre"))));
   
    }
    
}

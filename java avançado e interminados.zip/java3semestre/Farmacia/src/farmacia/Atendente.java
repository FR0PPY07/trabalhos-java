
package farmacia;

public class Atendente extends Funcionario {
    
    private int idade;

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Atendente(int idade, int matricula, String nome, Double salario) {
        super(matricula, nome, salario);
        this.idade = idade;
    }

    @Override
    public String toString() {
        return "Atendente{" + "idade=" + idade + '}';
    }
    
    
}

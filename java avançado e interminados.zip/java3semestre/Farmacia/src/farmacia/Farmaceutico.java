
package farmacia;


public class Farmaceutico extends Funcionario {
    private String formacao;

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }

    public Farmaceutico(String formacao, int matricula, String nome, Double salario) {
        super(matricula, nome, salario);
        this.formacao = formacao;
    }

    @Override
    public String toString() {
        return "Farmaceutico{" + "formacao=" + formacao + '}';
    }
    
    
}

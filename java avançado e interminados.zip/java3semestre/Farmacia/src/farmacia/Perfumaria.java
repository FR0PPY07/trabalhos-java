
package farmacia;


public class Perfumaria extends Produto {
    
    private Double desconto;
    private String secao;

    public Double getDesconto() {
        return desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }

    public String getSecao() {
        return secao;
    }

    public void setSecao(String secao) {
        this.secao = secao;
    }

    public Perfumaria(Double desconto, String secao, String codigo, String nome, String preco) {
        super(codigo, nome, preco);
        this.desconto = desconto;
        this.secao = secao;
    }

    @Override
    public String toString() {
        return "Perfumaria{" + "desconto=" + desconto + ", secao=" + secao + '}';
    }
    
    
    
}

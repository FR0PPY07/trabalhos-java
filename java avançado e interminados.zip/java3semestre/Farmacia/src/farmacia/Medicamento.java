
package farmacia;
public class Medicamento extends Produto {
    
    private String tarja;
    private String doenca;

    public String getTarja() {
        return tarja;
    }

    public void setTarja(String tarja) {
        this.tarja = tarja;
    }

    public String getDoenca() {
        return doenca;
    }

    public void setDoenca(String doenca) {
        this.doenca = doenca;
    }

    public Medicamento(String tarja, String doenca, String codigo, String nome, String preco) {
        super(codigo, nome, preco);
        this.tarja = tarja;
        this.doenca = doenca;
    }

    @Override
    public String toString() {
        return "Medicamento{" + "tarja=" + tarja + ", doenca=" + doenca + '}';
    }
    
    
}

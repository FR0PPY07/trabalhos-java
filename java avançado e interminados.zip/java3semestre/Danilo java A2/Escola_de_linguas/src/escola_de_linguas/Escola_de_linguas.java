
package escola_de_linguas;

public class Escola_de_linguas {

    public static void main(String[] args) {
     
        
    }
    
}

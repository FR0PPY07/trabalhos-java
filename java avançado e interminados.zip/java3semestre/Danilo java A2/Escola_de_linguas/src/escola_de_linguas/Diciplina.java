
package escola_de_linguas;

public class Diciplina {
    
    private String idioma;
    private int codigo;

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Diciplina(String idioma, int codigo) {
        this.idioma = idioma;
        this.codigo = codigo;
    }
    
    
}

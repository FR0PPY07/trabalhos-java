
package escola_de_linguas;

public class Professor {
    
    private String nome, formacao, cpf;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Professor(String nome, String formacao, String cpf) {
        this.nome = nome;
        this.formacao = formacao;
        this.cpf = cpf;
    }

    @Override
    public String toString() {
        return "Professor" + 
                "\n nome:" + nome + 
                "\n formacao:" + formacao + 
                "\n cpf:" + cpf;
    }
    
    
}

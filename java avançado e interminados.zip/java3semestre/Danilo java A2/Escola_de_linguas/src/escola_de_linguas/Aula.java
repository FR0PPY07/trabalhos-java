
package escola_de_linguas;

public class Aula {
    
    private int qtdAlunos;
    private String turno;
    private Ingles ingles;
    private Japones japones;
    private Espanhol espanhol;
    private Aluno aluno;
    private Professor professor;

    public int getQtdAlunos() {
        return qtdAlunos;
    }

    public void setQtdAlunos(int qtdAlunos) {
        this.qtdAlunos = qtdAlunos;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public Ingles getIngles() {
        return ingles;
    }

    public void setIngles(Ingles ingles) {
        this.ingles = ingles;
    }

    public Japones getJapones() {
        return japones;
    }

    public void setJapones(Japones japones) {
        this.japones = japones;
    }

    public Espanhol getEspanhol() {
        return espanhol;
    }

    public void setEspanhol(Espanhol espanhol) {
        this.espanhol = espanhol;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public Aula(int qtdAlunos, String turno, Ingles ingles, Japones japones, Espanhol espanhol, Aluno aluno, Professor professor) {
        this.qtdAlunos = qtdAlunos;
        this.turno = turno;
        this.ingles = ingles;
        this.japones = japones;
        this.espanhol = espanhol;
        this.aluno = aluno;
        this.professor = professor;
    }

    @Override
    public String toString() {
        return "Aula" + 
                "\n qtdAlunos:" + qtdAlunos + 
                "\n turno:" + turno + 
                "\n ingles:" + ingles + 
                "\n japones:" + japones + 
                "\n espanhol:" + espanhol + 
                "\n aluno:" + aluno + 
                "\n professor:" + professor;
    }
    
    
}


package escola_de_linguas;

public class Aluno {
    
    private String nome, matricula, cpf;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Aluno(String nome, String matricula, String cpf) {
        this.nome = nome;
        this.matricula = matricula;
        this.cpf = cpf;
    }

    @Override
    public String toString() {
        return "Aluno" + 
                "\n nome:" + nome + 
                "\n matricula:" + matricula + 
                "\n cpf:" + cpf;
    }
    
    
}


package escola_de_linguas;

public class Espanhol extends Diciplina {
    
    private String diasSemana, horas;

    public String getDiasSemana() {
        return diasSemana;
    }

    public void setDiasSemana(String diasSemana) {
        this.diasSemana = diasSemana;
    }

    public String getHoras() {
        return horas;
    }

    public void setHoras(String horas) {
        this.horas = horas;
    }

    public Espanhol(String diasSemana, String horas, String idioma, int codigo) {
        super(idioma, codigo);
        this.diasSemana = diasSemana;
        this.horas = horas;
    }

    @Override
    public String toString() {
        return "Espanhol" + 
                "\n diasSemana:" + diasSemana + 
                "\n horas:" + horas +
                "\n idioma:" + getIdioma() +
                "\n codigo:" + getCodigo();
    }
    
    
}
